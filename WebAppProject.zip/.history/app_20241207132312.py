import uuid
print("retailserver-" + str(uuid.uuid4())[:8])